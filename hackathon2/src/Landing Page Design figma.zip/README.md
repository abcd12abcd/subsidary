
  # Landing Page Design

  This is a code bundle for Landing Page Design. The original project is available at https://www.figma.com/design/Gg4KVUSILiWo4GA7e9T82O/Landing-Page-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  