import { Button } from "./components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./components/ui/card";
import { Badge } from "./components/ui/badge";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";
import { CheckCircle, Shield, Zap, Globe, ArrowRight, Users, TrendingUp, Building2, Menu, X } from "lucide-react";
import { AdminLogin } from "./components/AdminLogin";
import { BusinessLogin } from "./components/BusinessLogin";
import { useState } from "react";

type Page = "landing" | "admin-login" | "business-login";

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("landing");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (currentPage === "admin-login") {
    return <AdminLogin onBack={() => setCurrentPage("landing")} />;
  }

  if (currentPage === "business-login") {
    return <BusinessLogin onBack={() => setCurrentPage("landing")} />;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-medium">SubsidyChain</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-foreground hover:text-primary transition-colors">Features</a>
              <a href="#how-it-works" className="text-foreground hover:text-primary transition-colors">How It Works</a>
              <a href="#benefits" className="text-foreground hover:text-primary transition-colors">Benefits</a>
              <div className="flex items-center space-x-3">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setCurrentPage("admin-login")}
                  className="flex items-center space-x-2"
                >
                  <Shield className="w-4 h-4" />
                  <span>Admin Login</span>
                </Button>
                <Button 
                  size="sm"
                  onClick={() => setCurrentPage("business-login")}
                  className="flex items-center space-x-2"
                >
                  <Building2 className="w-4 h-4" />
                  <span>Business Login</span>
                </Button>
              </div>
            </div>
            
            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>
          
          {/* Mobile menu */}
          {mobileMenuOpen && (
            <div className="md:hidden border-t border-border">
              <div className="px-4 py-4 space-y-4">
                <a href="#features" className="block text-foreground hover:text-primary transition-colors">Features</a>
                <a href="#how-it-works" className="block text-foreground hover:text-primary transition-colors">How It Works</a>
                <a href="#benefits" className="block text-foreground hover:text-primary transition-colors">Benefits</a>
                <div className="space-y-2 pt-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="w-full flex items-center justify-center space-x-2"
                    onClick={() => {
                      setCurrentPage("admin-login");
                      setMobileMenuOpen(false);
                    }}
                  >
                    <Shield className="w-4 h-4" />
                    <span>Admin Login</span>
                  </Button>
                  <Button 
                    size="sm"
                    className="w-full flex items-center justify-center space-x-2"
                    onClick={() => {
                      setCurrentPage("business-login");
                      setMobileMenuOpen(false);
                    }}
                  >
                    <Building2 className="w-4 h-4" />
                    <span>Business Login</span>
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge variant="secondary" className="mb-4">
                Smart Contract Automation
              </Badge>
              <h1 className="text-4xl lg:text-5xl font-bold mb-6 leading-tight">
                Automate Government Subsidies for{" "}
                <span className="text-primary">Green Hydrogen</span> Projects
              </h1>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Revolutionary smart contract platform that automatically verifies project milestones and triggers subsidy payments in real-time. Eliminate delays, reduce bureaucracy, and accelerate the green energy transition.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="text-base"
                  onClick={() => setCurrentPage("business-login")}
                >
                  Apply for Subsidies
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="text-base"
                  onClick={() => setCurrentPage("admin-login")}
                >
                  <Shield className="w-4 h-4 mr-2" />
                  Government Access
                </Button>
              </div>
              <div className="flex items-center space-x-6 mt-8 text-sm text-muted-foreground">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Automated Verification</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Shield className="w-4 h-4 text-blue-500" />
                  <span>Audit Trails</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Globe className="w-4 h-4 text-purple-500" />
                  <span>Legacy Integration</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1616765753552-818085398cd4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlbiUyMGh5ZHJvZ2VuJTIwcmVuZXdhYmxlJTIwZW5lcmd5fGVufDF8fHx8MTc1NjUwNjM3MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Green hydrogen renewable energy infrastructure"
                className="w-full h-96 object-cover rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent rounded-2xl"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2">95%</div>
              <div className="text-sm text-muted-foreground">Processing Time Reduction</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2">$2.3B+</div>
              <div className="text-sm text-muted-foreground">Subsidies Processed</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2">100%</div>
              <div className="text-sm text-muted-foreground">Audit Compliance</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2">24/7</div>
              <div className="text-sm text-muted-foreground">Real-time Monitoring</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">
              Platform Features
            </Badge>
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Intelligent Automation for Government Incentives
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our platform leverages blockchain technology to create transparent, efficient, and secure subsidy distribution systems.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-2 hover:border-primary/20 transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Smart Contract Automation</CardTitle>
                <CardDescription>
                  Programmable contracts that automatically execute payments when predefined milestones are verified through trusted data sources.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 hover:border-primary/20 transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center mb-4">
                  <CheckCircle className="w-6 h-6 text-green-500" />
                </div>
                <CardTitle>Real-time Milestone Verification</CardTitle>
                <CardDescription>
                  Automated verification of project achievements including hydrogen production volumes, completion stages, and environmental impact metrics.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 hover:border-primary/20 transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-blue-500" />
                </div>
                <CardTitle>Complete Audit Trails</CardTitle>
                <CardDescription>
                  Immutable blockchain records provide full transparency and traceability for all transactions and milestone verifications.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 hover:border-primary/20 transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-500/10 rounded-lg flex items-center justify-center mb-4">
                  <Globe className="w-6 h-6 text-purple-500" />
                </div>
                <CardTitle>Legacy System Integration</CardTitle>
                <CardDescription>
                  Seamless integration with existing government payment platforms and banking systems for smooth implementation.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 hover:border-primary/20 transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-orange-500/10 rounded-lg flex items-center justify-center mb-4">
                  <TrendingUp className="w-6 h-6 text-orange-500" />
                </div>
                <CardTitle>Performance Analytics</CardTitle>
                <CardDescription>
                  Real-time dashboards and reporting tools to monitor project progress, payment flows, and system performance metrics.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-2 hover:border-primary/20 transition-all duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-red-500/10 rounded-lg flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-red-500" />
                </div>
                <CardTitle>Multi-stakeholder Access</CardTitle>
                <CardDescription>
                  Role-based access controls for government agencies, project developers, auditors, and other stakeholders in the ecosystem.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20 bg-muted/30 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">
              Process Overview
            </Badge>
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              How Our Platform Works
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              A streamlined process that transforms traditional subsidy distribution into an automated, transparent system.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <ImageWithFallback
                src="https://thumbs.dreamstime.com/b/comparing-green-earth-effect-air-pollution-human-action-glbal-warming-concept-green-tree-green-earth-light-144880970.jpg"
                alt="Smart contracts and blockchain technology"
                className="w-full h-80 object-cover rounded-2xl"
              />
            </div>
            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold">
                  1
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Project Registration & Contract Setup</h3>
                  <p className="text-muted-foreground">Government agencies and project developers register green hydrogen projects with predefined milestones and payment terms in smart contracts.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold">
                  2
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Real-time Data Integration</h3>
                  <p className="text-muted-foreground">IoT sensors, production meters, and trusted data sources continuously feed project performance data into the verification system.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold">
                  3
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Automated Milestone Verification</h3>
                  <p className="text-muted-foreground">Smart contracts automatically verify when milestones are achieved based on real-time data, eliminating manual review processes.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold">
                  4
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Instant Payment Execution</h3>
                  <p className="text-muted-foreground">Upon successful verification, the system automatically triggers subsidy payments through integrated banking and government payment platforms.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="benefits" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge variant="secondary" className="mb-4">
              Key Benefits
            </Badge>
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Benefits for All Stakeholders
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-blue-500/10 rounded-lg flex items-center justify-center">
                    <Shield className="w-5 h-5 text-blue-500" />
                  </div>
                  <span>For Government Agencies</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Reduce administrative overhead by 95%</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Ensure 100% compliance and audit readiness</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Accelerate green energy transition goals</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Eliminate fraud and payment delays</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-green-500/10 rounded-lg flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-green-500" />
                  </div>
                  <span>For Project Developers</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Receive payments immediately upon milestone completion</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Transparent tracking of project progress</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Improved cash flow and project financing</span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Reduced bureaucratic delays and paperwork</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Ready to Transform Your Subsidy Program?
          </h2>
          <p className="text-lg mb-8 opacity-90">
            Join leading government agencies and project developers who are already using our platform to accelerate the green energy transition.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              variant="secondary" 
              className="text-base"
              onClick={() => setCurrentPage("business-login")}
            >
              <Building2 className="w-4 h-4 mr-2" />
              Start Your Application
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-base border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary"
              onClick={() => setCurrentPage("admin-login")}
            >
              <Shield className="w-4 h-4 mr-2" />
              Admin Portal
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted/30 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Zap className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="font-medium">SubsidyChain</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Revolutionizing government subsidy distribution through smart contract automation.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Documentation</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">API Reference</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Security</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Press</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Technical Support</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">System Status</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Legal</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2025 SubsidyChain. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}